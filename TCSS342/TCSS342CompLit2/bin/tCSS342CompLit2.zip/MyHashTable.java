// Produced by Eli Cole

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

// My version of a hash table.
public class MyHashTable<K, V> implements Iterable<MyHashTable<K, V>.MyHashNode<K, V>>{
	private ArrayList<MyHashNode<K, V>> buckets;
	private int size;
	
	MyHashTable(int capacity) {
		buckets = new ArrayList<MyHashNode<K, V>>();
		for(int i = 0; i < capacity; i++) buckets.add(null);
	}
	
	public int size() {return size;}
	public boolean isEmpty() {return size == 0;}
	
	public void put(K searchKey, V newValue) {
	    int hash = hash(searchKey), hashHolder = hash;
        
        while(buckets.get(hash) != null && buckets.get(hash).key.hashCode() != searchKey.hashCode()) {
            hash++;
            if(hash == hashHolder) return; // A full loop of the buckets was completed, no empty space.
            if(hash == buckets.size()) hash = 0;
        }
        if(buckets.get(hash) == null) this.size++;
        buckets.remove(hash);
        buckets.add(hash, new MyHashNode<K, V>(searchKey, newValue));
	}
	
	public V get(K searchKey) {
	    int hash = hash(searchKey), hashHolder = hash;
        
	    if(buckets.get(hash) == null) return null;
        while(buckets.get(hash).key.hashCode() != searchKey.hashCode()) {
            hash++;
            if(hash == buckets.size()) hash = 0;
            if(buckets.get(hash) == null || hash == hashHolder) return null;
        }
        return buckets.get(hash).value;
	}
	
	public boolean containsKey(K searchKey) {
		if(this.get(searchKey) == null) return false;
		return true;
	}
	
	public int findHashBucket(K searchKey) {
		int hash = hash(searchKey), hashHolder = hash, steps = 0;
		
		if(buckets.get(hash) == null) return -1;
        while(buckets.get(hash).key.hashCode() != searchKey.hashCode()) {
            hash++;
            steps++;
            if(hash == buckets.size()) hash = 0;
            if(buckets.get(hash) == null || hash == hashHolder) return -1;
        }
		return steps;
	}
	
	// TODO: stats() is not finished. histogram should stop printing zeroes after last value, and also needs last couple percents added.
	public void stats() {
		System.out.println("\nHash Table Stats");
		System.out.println("=======================");
		System.out.println("Number of Entries: " + this.size());
		System.out.println("Number of Buckets: " + buckets.size());
		System.out.print("Histogram of Probes:\n[");
		MyHashTable<Integer, Integer> probeFreqs = new MyHashTable<Integer, Integer>(this.size());
		HashSet<K> keySet =  this.keySet();
		keySet.forEach((k) -> {
			int probe = findHashBucket(k);
			if(probe >= 0 && probeFreqs.containsKey(probe)) probeFreqs.put(probe, probeFreqs.get(probe) + 1);
			else if (probe >= 0) probeFreqs.put(probe, 1);
		});
		int counter = 0;
		int isDone = 0;
		int max = 0;
		int totalProbes = 0;
		for(int i = 0; i < buckets.size(); i++) {
		    if(i != 0) System.out.print(", ");
			if(probeFreqs.containsKey(i)) {
			    System.out.print(probeFreqs.get(i));
			    isDone++;
			    max = i;
			    totalProbes += i * probeFreqs.get(i);
			}
			else System.out.print("0");
			counter++;
			if(counter % 45 == 0 && counter != 0) System.out.println();
			if(isDone == probeFreqs.size()) i = buckets.size();
		}
		System.out.println("]\nFill Percentage: " + ((float) this.size() / buckets.size() * 100) + "%");
		System.out.println("Max Linear Probe: " + max);
		System.out.println("Average Linear Probe: " + ((float) totalProbes / this.size()));
	}
	private int hash(K key) {return Math.abs(key.hashCode()) % buckets.size();}
	
	@Override
	public String toString() {
	    StringBuilder s = new StringBuilder();
	    s.append("[");
	    this.keySet().forEach((k) -> {
	        s.append(k);
	        s.append(" ");
	        s.append(this.get(k));
	        s.append(", ");
	    });
	    s.deleteCharAt(s.length() - 1);
	    s.append("]");
	    return s.toString();
	}
	
	public HashSet<K> keySet(){
	    HashSet<K> keySet = new HashSet<K>();
	    for(int i = 0; i < buckets.size(); i++) if(buckets.get(i) != null) keySet.add(buckets.get(i).key);
	    return keySet;
	}
	
	@Override
    public Iterator<MyHashTable<K, V>.MyHashNode<K, V>> iterator() {return new MyHashTableIterator();} 
	
	// Internal node class. Null values indicates this is a placeholder node within the table.
	@SuppressWarnings("hiding")
    class MyHashNode<K, V> { 
	    K key; 
	    V value;
	    
	    public MyHashNode(K newKey, V newValue) { 
	        this.key = newKey; 
	        this.value = newValue;
	    }
	    public MyHashNode() {
	    	this.key = null;
	    	this.value = null;
	    }
	    @Override
	    public String toString() {return "{" + key.toString() + ", " + value.toString() + "}";}
	}
	
	// Internal iterator class, so i can use forEach
	// TODO: this implementation of iterator is broke somehow. It works fine most the time but throws some sort of
	// index out of bound exception when CodingTree runs.
	class MyHashTableIterator implements Iterator<MyHashTable<K, V>.MyHashNode<K, V>> {
	    private int index = 0;
	    
        @Override
        public boolean hasNext() {return index < size();}
        @Override
        public MyHashTable<K, V>.MyHashNode<K, V> next() {
            while(buckets.get(index) == null) index++;
            return buckets.get(index++);
        }
	}
}
