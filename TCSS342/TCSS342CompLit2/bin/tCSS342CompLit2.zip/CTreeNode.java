// Brought into being by Eli Cole

// Internal tree-node class, used for building a Huffman character tree. Stores a char value (null value indicates this is a branch, not a leaf),
// as well as the frequency (weight) of this node and a String of ones and zeroes denoting its location in the tree.
public class CTreeNode<T> implements Comparable<CTreeNode<T>>{
	final private T value;
	private String loc;
	private int freq;
	final private CTreeNode<T> left;
	final private CTreeNode<T> right;
	
	CTreeNode(T value, int freq){
		this.left = null;
		this.right = null;
		this.value = value;
		this.loc = "";
		this.freq = freq;
	}
	CTreeNode(CTreeNode<T> left, CTreeNode<T> right, T value){
		this.left = left;
		this.right = right;
		this.value = value;
		this.setLoc("");
		freq = 0;
		if(left != null) freq = freq + left.freq();
		if(right != null) freq = freq + right.freq();
	}
	
	public void setLoc(String loc) {
		this.loc = loc;
		if (left != null) left.setLoc(loc + "0");
		if (right != null) right.setLoc(loc + "1");
	}
	public CTreeNode<T> left() {return left;}
	public CTreeNode<T> right() {return right;}
	public T value() {return value;}
	public String loc() {return loc;}
	public int freq() {return freq;}
    @Override
    public int compareTo(CTreeNode<T> other) {return this.freq() - other.freq();}
    @Override
    public boolean equals(Object other) {return other instanceof CTreeNode<?> && this.value() == ((CTreeNode<?>) other).value();}
}
